/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package purse;

import java.util.ArrayList;
import java.lang.String;

public class Purse {

    public ArrayList<String> wallet = new ArrayList<String>();
    
    public void addCoin(String coinName)
    {
        wallet.add(coinName) ;
    } 
    
    public ArrayList<String> reverse()
    {
        ArrayList<String> RePurse = new ArrayList<String>();
        for(int i=wallet.size()-1 ; i >= 0; i-- )
        {
            //int cnt = i + (wallet.size() - 1) ;
            RePurse.add(wallet.get(i));
            
        }
        return RePurse ;
        
    }
    
    public void transfer(Purse other)
    {
        int walletSize = wallet.size() ;
        for(int i=0 ; i < walletSize; i++ )
        {
            other.wallet.add(wallet.get(i));
        }
        for(int i=0 ; i < walletSize; i++ )
        {
            wallet.remove(0);
        }
    }
    
    public boolean sameContents(Purse other)
    {
        boolean check = false ;
            if(other.wallet.size() == this.wallet.size()){
            for(int i = 0;i < other.wallet.size(); i++){
                if(other.wallet.get(i) == this.wallet.get(i))
                {
                    check = true ;
                }
                else{
                check = false ;
                }
            }
            
            }
        return check ;
    }
    
    public boolean sameCoins(Purse other)
    {
        boolean check = false ;
            if(other.wallet.size() == this.wallet.size()){
            for(int i = 0;i < wallet.size(); i++){
                int w1Coin = 0 ;
                int w2Coin = 0 ;
                for(int j = 0;j < other.wallet.size(); j++){
                    if(other.wallet.get(j) == this.wallet.get(i))
                    {
                        w2Coin += 1 ;
                    }
                    if(this.wallet.get(i) == this.wallet.get(j))
                    {
                        w1Coin += 1 ;
                    }
                    
                }
                if(w1Coin == w2Coin)
                {
                    check = true ;
                }else{
                    check = false ;
                }
            }
            
            }
        return check ;
    }
    
    public String toString()
    {
        String s1 = "Purse"+wallet ;
        return s1 ;
    }
    /**public static void main(String[] args) {
        // TODO code application logic here
    }**/
    
}
