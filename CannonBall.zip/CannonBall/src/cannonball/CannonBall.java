/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cannonball;

/**
 *
 * @author usci
 */
public class CannonBall {
    
    public static final double g = 9.81 ;
    public double deltaT = 0.01 ;
    private double initV ;
    private double simS  ;
    private double simT ;
    private double deltaS ;
    private double DisT ;
    private double calV ;
    
    public CannonBall(double V)
    {
        initV = V;
        calV = V ;
    }

    public void simulatedFlight()
    {
        int time = 0 ;
        while(initV > 0)
        {
            simS += initV*0.01;
            initV -= g*0.01;
            time++;
            if (time%100 == 0){
            System.out.printf("Distance on %d sec: %.3f\n",time/100,simS);}
        }
       simT = time/100.0;
       System.out.printf("Final distance: %.3f Total time: %.2f\n",simS,simT);
    }
    
    public double calculusFlight(double t)
    {
        double cal = ((-0.5)*g*Math.pow(t,2))+(calV*t);
        return cal ;
    }
    
    public double getSimulatedTime()
    {
        return simT ;
    }
    
    public double getSimulatedDistance()
    {
        
        return simS ;
    }
}
