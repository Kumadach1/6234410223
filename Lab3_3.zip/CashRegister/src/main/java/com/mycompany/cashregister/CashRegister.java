/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.cashregister;

public class CashRegister {
    
    public double tax ;
    public double price ;
    public double balance ;
    public double change;
    public double all_tax;
    
    public CashRegister(double tax_rate)
    {
        tax = tax_rate ;
    }
    
    public void enterPayment(double money)
    {
        
        balance += money ;
    }
    
    public void recordPurchase(double cost)
    {
        price += cost ;
    } 
    
    public void recordTaxablePurchase(double cost)
    {
        price += cost + (cost*tax/100.0) ;
        all_tax += (cost*tax/100.0) ;
    }
    
    public double getTotalTax(){
        return all_tax; //return all of vat?
    }
    
    public double giveChange()
    {
        change = balance - price ;
        change = (Math.round(change*10.0))/10.0;
        return change ;
    }
}
