/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.cashregister;

public class CashRegisterTester {
    public static void main(String[] args) {
        CashRegister cashreg = new CashRegister(7);
        cashreg.enterPayment(100);
        cashreg.recordPurchase(50);
        cashreg.recordPurchase(10);
        cashreg.recordTaxablePurchase(20);
        System.out.println("Your change is "+cashreg.giveChange());
    }
    
}
