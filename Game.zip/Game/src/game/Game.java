/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.util.Scanner ;
import java.util.Random;
import java.lang.String ;

public class Game {

    String player ;
    boolean checkInput = true ;
    boolean checkWinner = true ;
    int scorePlayer ;
    int scoreComputer ;
    String computer ;
    int scorePlayerF ;
    int scoreComputerF ;
    
    public void play()
    {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        while(checkWinner) //checking who is the winner form the rule (Score different by 2)
        {
            while(checkInput) //checking for input correctly
            {
                System.out.print("Enter 0 for ROCK, 1for PAPER, 2 for SCISSORS :");
                player = sc.next();
                if(player.equals("0") || player.equals("1") || player.equals("2")) 
                {
                    checkInput = false ; //checking for input correctly
                }
            }
            switch(player)
            {
                case "0" :
                    System.out.println("You enter: ROCK");
                    break;
                case "1" :
                    System.out.println("You enter: PAPER");
                    break;
                case "2" :
                    System.out.println("You enter: SCISSORS");
                    break;
            }
            
            computer = Integer.toString(rand.nextInt(3)); //random number for computer
            
            switch(computer)
            {
                case "0" :
                    System.out.println("Computer: ROCK");
                    break;
                case "1" :
                    System.out.println("Computer: PAPER");
                    break;
                case "2" :
                    System.out.println("Computer: SCISSORS");
                    break;
            }
            if(player.equals("0"))
            {
                if(computer.equals("0"))
                {
                    System.out.println("it's a tie.");
                    checkInput = true ;
                }
                if(computer.equals("1"))
                {
                    System.out.println("You lose!");
                    scoreComputer += 1 ;
                    checkInput = true ;
                }
                if(computer.equals("2"))
                {
                    System.out.println("You win!");
                    scorePlayer += 1 ;
                    checkInput = true ;
                }
            }
            if(player.equals("1"))
            {
                if(computer.equals("0"))
                {
                    System.out.println("You win!");
                    scorePlayer += 1;
                    checkInput = true ;
                }
                if(computer.equals("1"))
                {
                    System.out.println("It's a tie.");
                    checkInput = true ;
                }
                if(computer.equals("2"))
                {
                    System.out.println("You lose!");
                    scoreComputer += 1 ;
                    checkInput = true ;
                }
            }
            if(player.equals("2"))
            {
                if(computer.equals("0"))
                {
                    System.out.println("You lose!");
                    scoreComputer += 1 ;
                    checkInput = true ;
                }
                if(computer.equals("1"))
                {
                    System.out.println("You win!");
                    scorePlayer += 1 ;
                    checkInput = true ;
                }
                if(computer.equals("2"))
                {
                    System.out.println("It's a tie.");
                    checkInput = true ;
                }
            }
            
            scorePlayerF = Integer.parseInt(player) ; //changing data type of player String to Int
            scoreComputerF = Integer.parseInt(computer) ; //changing data type of computer String to Int
            
            if(Math.abs(scorePlayer - scoreComputer) == 2) //checking difference of score is 2?
            {
                if(scorePlayer > scoreComputer) //player win
                {
                    System.out.println("-------------------------------------");
                    System.out.println("Congrats! You win.");
                    System.out.println("User Score:"+scorePlayer);
                    System.out.println("Computer Score:"+scoreComputer);
                    checkWinner = false;
                }
                if(scorePlayer < scoreComputer) //player lose
                {
                    System.out.println("-------------------------------------");
                    System.out.println("Too bad! You lose.");
                    System.out.println("User Score:"+scorePlayer);
                    System.out.println("Computer Score:"+scoreComputer);
                    checkWinner = false;
                }
            }
        } 
    }
    
    
}
