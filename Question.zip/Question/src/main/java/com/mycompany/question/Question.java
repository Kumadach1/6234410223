/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.question;

import java.lang.String ;
import java.util.ArrayList ;

public class Question {
    
    private String text,answer ;
    
    public Question()
    {
      text = null ;
      answer = null ;
    }
    
    public Question(String Message)
    {
        text = Message ;
    }
    
    public void setText(String ques)
    {
        text = ques ;
    }
    
    public void setAnswer(String ans)
    {
        answer = ans ;
    }
    
    public String getText()
    {
        return text ;
    }
    
    public String getAnswer()
    {
        return answer ;
    }
    
    public boolean checkAnswer(String response)
    {
        return response.equals(answer) ;
    }
    
    public void display()
    {
        System.out.println(text);
    }
    
}

class NumericQuestion extends Question {
    
    public NumericQuestion(String message)
    {
        super.setText(message);
    }
    
    @Override
    public boolean checkAnswer(String response)
    {
        return response.equals(super.getAnswer()) ;
    }

}

class ChoiceQuestion extends Question {
    
    ArrayList<String> choice = new ArrayList<String>();;
    
    public ChoiceQuestion(String message)
    {
        super.setText(message);
    }
    
    public void addChoice(String choice, boolean correct)
    {
        this.choice.add(""+(this.choice.size()+1)+": "+choice) ;
        if(correct)
        {
            super.setAnswer(Integer.toString(this.choice.size()));
        }
    }
    
    @Override
    public void display()
    {
        System.out.println(super.getText());
        for(int i = 0 ; i < choice.size() ; i++)
        {
            System.out.println(choice.get(i));
        }
    }
    
    @Override
    public boolean checkAnswer(String response)
    {
        return response.equals(super.getAnswer()) ;
    }
}
