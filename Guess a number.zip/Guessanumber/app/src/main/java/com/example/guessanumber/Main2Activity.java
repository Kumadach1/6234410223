package com.example.guessanumber;

import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.guessanumber.MESSAGE";
    public boolean check = true;
    Random rand = new Random();
    int answer = rand.nextInt(100)+1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        //TextBox
        final EditText txtName = (EditText) findViewById(R.id.editText1);
        //Submit Button
        final Button subMitfrm = (Button) findViewById(R.id.button);
        //Click Event

            subMitfrm.setOnClickListener((v) -> {
                        if (txtName.getText().toString().trim().equals(""))
                            txtName.setError("Please enter number");
                        else {

                            if (txtName.getText().toString().equals(Integer.toString(answer))) {
                                Intent i = new Intent(getApplicationContext(), Main3Activity.class);
                                startActivity(i);
                            } else {
                                String value = txtName.getText().toString();
                                int finalValue = Integer.parseInt(value);
                                if (finalValue < answer) {
                                    String t1 = "Your guess is too low";
                                    ((TextView) findViewById(R.id.textView3)).setText(t1);
                                }
                                if (finalValue > answer) {
                                    String t2 = "Your guess is too high";
                                    ((TextView) findViewById(R.id.textView3)).setText(t2);
                                }
                            }

                        }


                    }

            );



    }
}
