/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.citygrid;

import java.util.Random ;

public class CityGrid {
    
    private int xCoor ; //x-coordinate
    private int yCoor ; //y-coordinate
    private int gridSize ; // size of city
    
    Random rand = new Random() ;
    
    public CityGrid()
    {
        gridSize = 100 ;
        xCoor = 5 ;
        yCoor = 5 ;
    }
    
    public void walk()
    {
        int walk = rand.nextInt(4);
        switch(walk)
        {
            case 0 :
                xCoor++;
            case 1 :
                xCoor--;
            case 2 :
                yCoor++;
            case 3 :
                yCoor--;
        }
        
    }
    
    public boolean isInCity()
    {
        boolean check = true;
        if(xCoor < 0 || xCoor > 10)
        {
            check = false ;
        }
        if(yCoor < 0 || yCoor >10)
        {
            check = false ;
        }
        return check ;
    }
    
    public void reset()
    {
        xCoor = 5 ;
        yCoor = 5 ;
    }
    
    public static void main(String[] args)
    {
        int step = 0;
        int maxStep = 0 ;
        int allStep = 0 ;
        double avgStep = 0 ;
        CityGrid city = new CityGrid() ;
        for(int i=0; i<10000 ;i++)
        {
            int cnt = 0 ;
            while(cnt < 1000)
            {
                city.walk();
                step += 1 ;
                cnt += 1 ;
                if(step > maxStep)
                {
                    maxStep = step ;
                }
                if(!city.isInCity() && (cnt < 1000))
                {
                    break ;
                }
            }
            allStep += step ;
            step = 0 ;
        }
        avgStep = allStep/10000.0 ;
        System.out.println("Average number of steps that a person can take and is still in the city: "+avgStep);
        System.out.println("Maximum number of steps that a person can take and is still in the city: "+maxStep);
    }
    
}
