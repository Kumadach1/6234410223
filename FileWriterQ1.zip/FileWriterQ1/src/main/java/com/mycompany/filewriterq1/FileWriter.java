/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.filewriterq1;

import java.io.File ;
import java.io.PrintWriter;
import java.util.Scanner;

public class FileWriter {
    
    public static void main(String[] args) throws Exception {
    
        int sum_char=0,sum_word=0,sum_line= -1 ;
        String text = null ;
        boolean check = true ;
        Scanner sc = new Scanner(System.in);
        File file = new File("write_here.txt");
        if(file.exists()) {
        
            System.out.println("File already exists,please change file name");
        
        }else {
        
        PrintWriter pw = new PrintWriter(file) ;
        //System.out.print("Enter text :");
        while(check) {
            
            text = sc.nextLine();
            sum_line += 1;
            
            if(text.equals("quit")) {
            
                check = false ;
        
            }else {
            
                pw.println(text);
                String[] words = text.split("\\s");
                sum_word += words.length ;
                sum_char += text.length();
                
            }
        }
        System.out.println("Total characters :"+sum_char);
        System.out.println("Total words :"+sum_word);
        System.out.println("Total lines :"+sum_line);
        pw.close();
        }
    
    }
    
}
