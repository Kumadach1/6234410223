/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.line;

/**
 *
 * @author TongC
 */
public class LineTester {
    public static void main(String[] args) {
    Line l1 = new Line(0,4) ;
    Line l2 = new Line(5) ;
    System.out.println("Are two lines equals?: "+l1.equals(l2)) ;
    System.out.println("Are two lines parallel?: "+l1.isParallel(l2));
    System.out.println("Do the two lines intersect?: "+l1.isIntersect(l2));
    if(l1.isIntersect(l2))
    {
        System.out.println("Point of intersection: "+l1.getIntersectionpoint(l2).getX()+","+l1.getIntersectionpoint(l2).getY());
    }
    }
}
