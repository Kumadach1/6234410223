/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.magicsquare;



public class MagicSquare {
    
    private int[][] square ;
    private int num ;
    
    public MagicSquare(int n)
    {
        square = new int[n][n];
        num = n;
        int mj = ((n+1)/2)-1;
        int mi = n-1;
       
        square[mi][mj] = 1;
        for(int i = 2 ; i <= n*n ; i++)
        {  
            if(square[(mi+1)%n][(mj+1)%n] !=0)
                 mi = (mi-1)%n;
           else
            {
           mi = (mi+1)%n;
           mj = (mj+1)%n;
            }
      
           square[mi][mj] = i;
        }
    }
    
    public String getSquare()
    {
        String output = "";
        for(int i = 0; i<num ;i++)
        {
            output +="";
             for(int j = 0; j<num ;j++)
             {
                 
                 output += square[i][j]>9? square[i][j]+"  ":square[i][j]+"   ";
             }
             output += "\n";
        }
        return output;
    }
    
}
