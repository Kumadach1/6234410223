/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.bus;

import java.util.ArrayList ;

public class BusTester {
   
    public static void main(String args[]){

        int cnt = 0 ;
        ArrayList<Bus> arr = new ArrayList<Bus>() ;
        arr.add(new Hybrid(45,1.2,700,150,1)) ;
        cnt ++ ;
        arr.add(new CNGBus(50,1,200,2));
        cnt ++;
        for(int i=0 ;i<cnt ;i++) {
            if(arr.get(i) instanceof CNGBus) {
                System.out.println("ID: "+arr.get(i).getID());
                System.out.println("Emmission Tier: "+((CNGBus)arr.get(i)).getEmissionTier());;
                System.out.println("Accel: "+((CNGBus)arr.get(i)).getAccel());
            }else if(arr.get(i) instanceof Hybrid) {
                System.out.println("ID: "+arr.get(i).getID());
                System.out.println("Emmission Tier: "+((Hybrid)arr.get(i)).getEmissionTier());
                System.out.println("Accel: "+((Hybrid)arr.get(i)).getAccel());
            }
        }
        
    }
}
