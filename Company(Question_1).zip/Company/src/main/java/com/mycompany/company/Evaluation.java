/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.company;

import java.lang.String;

public interface Evaluation {
    
    double evaluate() ;
    
    char grade(double score) ;
    
}

class Employee {

    private String name ;
    private int salary ;
    
    public Employee(String name,int salary) {
        this.name = name ;
        this.salary = salary ;
    }
    
    public void setSalary(int salary) {
        this.salary = salary ;
    }
    
    @Override
    public String toString() {
        return ""+name+"\nsalary = "+salary ;
    }
    
}

class Secretary extends Employee implements Evaluation {

    private int speed ;
    private int[] score ;
    
    public Secretary(String name,int salary,int[] sc,int speed) {
        super(name,salary);
        score = sc ;
        this.speed = speed ;
    }
    
    @Override
    public double evaluate() {
        int sum = 0 ;
        for(int i=0 ; i < 2; i++) {
            sum += score[i] ;
        }
        return sum ;
    }
    
    @Override
    public char grade(double score) {
        if(score >= 90){
            super.setSalary(18000);
            return 'P' ;
        }
        else return 'F' ;
    }
    
}

class Subject implements Evaluation {

    private String subjName ;
    private int[] score ;
    
    public Subject(String name,int[] score) {
        this.subjName = name ;
        this.score = score ;
    }
    
    @Override
    public double evaluate() {
        int sum = 0 ;
        for(int i = 0; i < score.length ; i++ ) {
            sum += score[i] ;
        } 
        return sum/score.length ;
    }
    
    @Override
    public char grade(double score) {
        if(evaluate() >= 70) {
            return 'P' ;
        }else {
            return 'F' ;
        }
    }
    
    @Override
    public String toString() {
        return subjName ;
    }
    
}
