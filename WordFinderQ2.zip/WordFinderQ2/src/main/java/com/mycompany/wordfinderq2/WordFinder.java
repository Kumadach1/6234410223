/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.wordfinderq2;

import java.util.Scanner ;
import java.io.File ;
import java.util.ArrayList ;
import java.io.FileNotFoundException ;
import java.util.Arrays;

public class WordFinder {
    public static void main(String[] args) {
    
        boolean check = true ;
        ArrayList<String> wordArray = new ArrayList<>();
        Scanner scReader = null ;
        
        try {
        
            File file = new File("wordlist.txt") ;
            scReader = new Scanner(file) ;
            while(scReader.hasNextLine()) {
            
                wordArray.add(scReader.nextLine());
            
            }
        
        } catch(FileNotFoundException e) {
            
            System.out.println("Error :");
            e.printStackTrace();
        
        } finally {
        
            if(scReader != null) {
                scReader.close();
            }
        
        }
    
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String[] sentence = sc.nextLine().split("\\s");
        System.out.println("Words not contained:");
        for(int i =0 ; i<sentence.length;i++) {
        
            if(!(wordArray.contains(sentence[i]))) {
                System.out.println(sentence[i]);
                check = false ;
            }
        
        }
        if(check){
                System.out.println("N/A");
        }
        
    }
}
