/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.zeller;

import java.util.Scanner;
public class TesterZeller {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter year(e.g., 2012): ");
        int year = sc.nextInt();
        System.out.print("Enter month (1-12): ");
        int month = sc.nextInt() ;
        System.out.print("Enter day of the month (1-31): ");
        int day = sc.nextInt();
        Zeller zeller = new Zeller(day,month,year);
        switch(zeller.getDayOfWeek()){
            case SUNDAY :
                System.out.println("Day of the week is Sunday");
                break;
            case MONDAY :
                System.out.println("Day of the week is Monday");
                break;
            case TUESDAY :
                System.out.println("Day of the week is Tuseday");
                break;
            case WEDNESDAY :
                System.out.println("Day of the week is Wednesday");
                break;
            case THURSDAY :
                System.out.println("Day of the week is Thursday");
                break;
            case FRIDAY :
                System.out.println("Day of the week is Friday");
                break;
            case SATURDAY :
                System.out.println("Day of the week is Saturday");
                break;
        
    }
    
}}
