/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.interfacetester;

import java.util.ArrayList;

/**
 *
 * @author TongC
 */
public class SelfCheckOut implements SimpleQueue {
    
    ArrayList<Product> itemArray = new ArrayList<>();
    double cost = 0 ;
    
    @Override
    public void enqueue(Object o){
    
        itemArray.add((Product) o);
        System.out.println(itemArray.get(itemArray.size()-1).getName()+" is added in queue");
        
    }
    
    @Override
    public void dequeue() {
        
        cost += itemArray.get(0).getPrice();
        itemArray.remove(0);
        
    }
    
    public double getAmount() {
    
        return cost ;
        
    }
}
