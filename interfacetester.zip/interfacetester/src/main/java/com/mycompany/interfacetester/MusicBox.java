/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.interfacetester;

 import java.util.ArrayList ;

public class MusicBox implements SimpleQueue {
    
    ArrayList<String> musicArray = new ArrayList<>();
    
    @Override
    public void enqueue(Object o){
    
        musicArray.add((String)o);
        System.out.println(musicArray.get(musicArray.size()-1)+" is added in queue");
        
    }
    
    @Override
    public void dequeue() {
        
        System.out.println("Now playing "+musicArray.get(0));
        musicArray.remove(0);
        
    }
    
}
