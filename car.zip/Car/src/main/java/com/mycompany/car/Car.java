/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.car;

/**
 *
 * @author TongC
 */
public class Car {
    
    double gas ;
    double efficiency ;
    
    public Car(double oil,double rateOil) //input a gas and efficiency
    {
        gas = oil ;
        efficiency = rateOil ;
    }
    
    public void drive(double distance) //calculate distance and decrese oil in tank
    {
        double gasCalculated = distance/efficiency ;
        
        if(gas < gasCalculated)
        {
           System.out.println("You cannot drive too far, please add gas") ;
        }else{
        
            gas -= gasCalculated ;
        }
    }
    
    public void setGas(double amount) //set amount of gas in tank
    {
        gas = amount ;
    }
    
    public double getGas() //return amount of gas in tank
    {
       return gas ; 
    }
    
    public double getEfficiency() //return efficiency
    {
        return efficiency ;
    }
    
    public void addGas(double amount) //add gas to tank
    {
        gas += amount ;
    }
}

class Truck extends Car{

    double M_weight,weight ;
    
    public Truck(double oil, double rateOil,double Mweight, double weightOBJ )
    {
        super(oil,rateOil);
        if(weightOBJ > Mweight)
        {
            M_weight = Mweight ;
            weight = Mweight ;
        }else{
            
            M_weight = Mweight ;
            weight = weightOBJ ;
        }
    }
    
    @Override
    public void drive(double distance)
    {
        if(weight < 1)
        {
            // Not consuming more oil
            
            double gasCalculated = distance/efficiency ;
        
            if(gas < gasCalculated)
            {
                System.out.println("You cannot drive too far, please add gas") ;
            }else{
        
                gas -= gasCalculated ;
            }
        
        }else if(weight >= 1 && weight <= 10)
        {
           double gasCalculated = ((distance/efficiency)*110)/100 ;
        
            if(gas < gasCalculated)
            {
                System.out.println("You cannot drive too far, please add gas") ;
            }else{
        
            gas -= gasCalculated ;
            } 
        }else if(weight >= 11 && weight <= 20)
        {
            double gasCalculated = ((distance/efficiency)*120)/100 ;
        
            if(gas < gasCalculated)
            {
                System.out.println("You cannot drive too far, please add gas") ;
            }else{
        
            gas -= gasCalculated ;
            } 
        }else if(weight > 20)
        {
            double gasCalculated = ((distance/efficiency)*130)/100 ;
        
            if(gas < gasCalculated)
            {
                System.out.println("You cannot drive too far, please add gas") ;
            }else{
        
            gas -= gasCalculated ;
            } 
        }
    }
}
