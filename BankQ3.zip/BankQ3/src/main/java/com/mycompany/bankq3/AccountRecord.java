/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.bankq3;

/**
 *
 * @author TongC
 */
public class AccountRecord {
    
    private int acctNo;
    private String name;
    private double balance;
    private int transCnt = 0; //count a number of transaction 
    
    public AccountRecord (int acctNo, String name, double balance) {
        this.acctNo = acctNo;
        this.name = name;
        this.balance = balance;
    }
    
    public void combine(TransactionRecord t){
    
        if(this.acctNo == t.getAccountNO()) {
            balance += t.getAmountOfTransaction();
            transCnt++ ;
        }
    
    }
    
    public int getAcctNo() { return acctNo; }
    public String getName() { return name; }
    public double getBalance(){ return balance; }
    public int getTransCnt() { return transCnt; }

}
