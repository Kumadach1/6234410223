/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.bankq3;

import java.util.ArrayList ;
import java.io.File ;
import java.util.Scanner ;
import java.io.IOException;
import java.io.RandomAccessFile;

public class FileMatch {
    
    public static void main(String[] args) throws Exception{
    
        
        ArrayList<AccountRecord> accountArray = new ArrayList<>();
        ArrayList<TransactionRecord> transactionArray = new ArrayList<>();
        
        File fileA = new File("master.txt");
        File fileB = new File("trans.txt");
        try (Scanner scReaderA = new Scanner(fileA);){
            
            while(scReaderA.hasNextLine()) {
            
                String[] ac = scReaderA.nextLine().split("\\s");
                AccountRecord ar = new AccountRecord(Integer.parseInt(ac[0]),ac[1]+" "+ac[2],Double.parseDouble(ac[3]));
                accountArray.add(ar); 
            }
            
        } catch(IOException e) {
            e.printStackTrace();
        }
        
        try (Scanner scReaderB = new Scanner(fileB);){
            
            while(scReaderB.hasNextLine()) {
            
                String[] ac = scReaderB.nextLine().split("\\s");
                TransactionRecord tr = new TransactionRecord(Integer.parseInt(ac[0]),Double.parseDouble(ac[1]));
                transactionArray.add(tr); 
            }
            
        } catch(IOException e) {
            e.printStackTrace();
        }
        
        for(int i=0; i<accountArray.size() ; i++) {//account
        
            for(int j=0; j<transactionArray.size();j++){//transaction
                accountArray.get(i).combine(transactionArray.get(j));
            }
        }
        
        //make a sentence section
        
        String name;
        int AccNo;
        double Balance;
        int Tcnt;
        double all_balance=0 ;
        int cntNottrans=0 ;
        int accCnt =0 ;
        
            try {
                RandomAccessFile file = new RandomAccessFile("newMaster.dat", "rw");
                for(int i=0;i<accountArray.size();i++){
                    name = accountArray.get(i).getName() ;
                    AccNo = accountArray.get(i).getAcctNo() ;
                    Balance = accountArray.get(i).getBalance() ;
                    Tcnt = accountArray.get(i).getTransCnt();
                    file.writeInt(AccNo);
                    while(name.length() < 30) {
                        name += ' ' ;
                    }
                    String sentence = name ;
                    file.writeChars(sentence);
                    file.writeDouble(Balance);
                    file.writeInt(Tcnt);
                    file.writeChar('\n');
                    
                }
                file.seek(0);
            } catch(IOException e) {
                e.printStackTrace();
            }
            
        //read a data from file
        
        try {
            
            RandomAccessFile file = new RandomAccessFile("newMaster.dat", "r");
    
            for(int i=0;i<accountArray.size();i++) {
            
                file.seek(file.getFilePointer()+64); //point at balance
                all_balance += file.readDouble() ; //read balance
                if(file.readInt() == 0){cntNottrans++;} //read amount of transaction
                accCnt++; // count an account
                file.seek(file.getFilePointer()+2); //skip a '\n' that 2 bytes
            }
/**
            //account1
            file.seek(0);
            //System.out.println(""+file.readInt());
            accCnt++;
            file.seek(64);
            all_balance += file.readDouble() ;
            if(file.readInt() == 0){cntNottrans++;}
            //account2
            file.seek(78);
            //System.out.println(""+file.readInt());
            accCnt++;
            file.seek(142);
            all_balance += file.readDouble() ;
            if(file.readInt() == 0){cntNottrans++;}
            //account3
            file.seek(156);
            //System.out.println(""+file.readInt());
            accCnt++;
            file.seek(220);
            all_balance += file.readDouble() ;
            if(file.readInt() == 0){cntNottrans++;}
            //account4
            file.seek(234);
            //System.out.println(""+file.readInt());
            accCnt++;
            file.seek(298);
            all_balance += file.readDouble() ;
            if(file.readInt() == 0){cntNottrans++;}
          **/
        } catch(IOException ex) {
            ex.printStackTrace();
        }
        
        System.out.println("Total Account Record : "+accCnt);
        System.out.println("Total Balance : "+all_balance);
        System.out.println("No transaction : "+cntNottrans+" account.");
}
    

}
