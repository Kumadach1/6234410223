/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.bankq3;

/**
 *
 * @author TongC
 */
public class TransactionRecord {
    
    private int account_number ;
    private double amountOfTransaction ;
    
    public TransactionRecord(int number,double money) {
        account_number = number ;
        amountOfTransaction = money ;
        
    }
    
    public void setAccountNO(int number) {
        account_number = number ;
    }
    
    public void setAmountOfTransaction(int number) {
        amountOfTransaction = number;
    }
    
    public int getAccountNO() {
        return account_number ;
    }
    
    public double getAmountOfTransaction() {
        return amountOfTransaction ;
    }
    
}
