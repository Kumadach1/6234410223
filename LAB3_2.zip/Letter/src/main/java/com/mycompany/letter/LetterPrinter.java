/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.letter;

import java.lang.String;

public class LetterPrinter {
    public static void main(String[] args) {
        String text = "we must find Simon quickly.\nHe might be in danger.";
        Letter letter = new Letter("Clarissa","Jade");
        letter.addLine(text);
        System.out.println(letter.getText());
    }
}
