/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.letter;

import java.lang.String;
public class Letter {
    
    public String Sender;
    public String Reciver;
    public String Message;
    
    public Letter(String from, String to)
    {
        Sender = from ;
        Reciver = to ;
    }
    
    public void addLine(String line)
    {
        Message = "Dear "+Reciver+":\n"+"\n"+line+"\n"+"\n"+"Sincerely,\n"+"\n"+Sender;
    }
    
    public String getText()
    {
        return Message ;
    }
}
